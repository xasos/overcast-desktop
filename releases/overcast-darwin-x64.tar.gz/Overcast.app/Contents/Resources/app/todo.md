# Todo list

_\( managed using [todo-md](https://github.com/Hypercubed/todo-md) \)_

- [ ] Add Build Script
- [ ] Add Content menu
- [ ] Redesign icon
- [ ] Fix icon + app name
- [ ] Windows support?
- [ ] Make Media Keys less greedy